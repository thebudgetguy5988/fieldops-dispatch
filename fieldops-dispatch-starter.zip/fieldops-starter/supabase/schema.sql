-- FieldOps Dispatch MVP schema for Supabase (Postgres).
-- Run in Supabase Dashboard > SQL Editor. Review/test all access policies before production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null default '',
  role text not null default 'technician' check (role in ('admin','dispatcher','technician')),
  created_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  customer_name text not null,
  address text not null,
  scheduled_at timestamptz,
  priority text not null default 'Normal' check (priority in ('Low','Normal','High','Urgent')),
  notes text not null default '',
  status text not null default 'Scheduled' check (status in ('Scheduled','En route','On site','Waiting for parts','Completed','Cancelled')),
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.technician_locations (
  technician_id uuid primary key references public.profiles(id) on delete cascade,
  latitude double precision not null check(latitude between -90 and 90),
  longitude double precision not null check(longitude between -180 and 180),
  accuracy_m integer,
  updated_at timestamptz not null default now()
);

create index if not exists jobs_assigned_to_idx on public.jobs(assigned_to);
create index if not exists jobs_scheduled_at_idx on public.jobs(scheduled_at);

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.technician_locations enable row level security;

-- Helper functions avoid recursive profile-policy lookups. Role is read from the signed-in user's profile.
create or replace function public.current_user_role() returns text
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;
create or replace function public.is_dispatcher() returns boolean
language sql stable security definer set search_path = public
as $$ select coalesce(public.current_user_role() in ('admin','dispatcher'), false) $$;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.is_dispatcher() to authenticated;

-- Profiles: users can read their own profile; dispatchers/admins can read the roster.
drop policy if exists "profile self or dispatch roster read" on public.profiles;
create policy "profile self or dispatch roster read" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_dispatcher());
-- Admins can manage role assignments; ordinary users must not promote themselves.
drop policy if exists "admin manage profiles" on public.profiles;
create policy "admin manage profiles" on public.profiles for all to authenticated
using (public.current_user_role() = 'admin') with check (public.current_user_role() = 'admin');

-- Jobs: dispatch can manage all calls; technicians can read assigned calls and update status only.
drop policy if exists "dispatch manage jobs" on public.jobs;
create policy "dispatch manage jobs" on public.jobs for all to authenticated
using (public.is_dispatcher()) with check (public.is_dispatcher());
drop policy if exists "technicians read assigned jobs" on public.jobs;
create policy "technicians read assigned jobs" on public.jobs for select to authenticated
using (assigned_to = auth.uid());
drop policy if exists "technicians update assigned job status" on public.jobs;
create policy "technicians update assigned job status" on public.jobs for update to authenticated
using (assigned_to = auth.uid()) with check (assigned_to = auth.uid());

-- Locations: technicians can write their own position; dispatchers/admins can view all positions.
drop policy if exists "technician write own location" on public.technician_locations;
create policy "technician write own location" on public.technician_locations for insert to authenticated
with check (technician_id = auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='technician'));
drop policy if exists "technician update own location" on public.technician_locations;
create policy "technician update own location" on public.technician_locations for update to authenticated
using (technician_id = auth.uid()) with check (technician_id = auth.uid());
drop policy if exists "dispatch read all locations" on public.technician_locations;
create policy "dispatch read all locations" on public.technician_locations for select to authenticated
using (public.is_dispatcher());

-- Enable Realtime for live board updates (ignore error if already enabled).
alter publication supabase_realtime add table public.jobs;
alter publication supabase_realtime add table public.technician_locations;
